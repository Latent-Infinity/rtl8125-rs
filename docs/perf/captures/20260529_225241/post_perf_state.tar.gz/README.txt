r8125_rust state dump
=====================
captured: 2026-05-29T23:30:10Z
hostname: rtl8125-guest
kernel  : 7.0.0
iface   : enp5s0
bdf     : 0000:05:00.0
since   : 1 hour ago

Files in this archive:
  dmesg.log            kernel log filtered to r8125_rust + link + BUG/WARN
  ethtool_drvinfo.txt  driver version / firmware
  ethtool_features.txt offload feature state
  ethtool_stats.txt    §6.3 counters + chip-internal stats
  interrupts.txt       /proc/interrupts (r8125_rust filter)
  lspci_chip.txt       lspci -vv for the chip
  lspci_bridge.txt     lspci -vv for upstream PCIe bridge (ASPM)
  iplink.txt           ip -s link show
  sysfs_iface.txt      operstate + carrier + speed + MTU
  module.txt           lsmod + module parameters
  debugfs/             contents of /sys/kernel/debug/r8125_rust/ if present
  six_three_gap.txt    §6.3 invariant gap calculation
